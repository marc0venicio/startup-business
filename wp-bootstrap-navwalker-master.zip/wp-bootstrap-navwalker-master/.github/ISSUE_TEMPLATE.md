<!-- Thanks for contributing to WP Bootstrap NavWalker! Pick a clear title and proceed. -->

#### Steps to reproduce the issue:

#### What I expected:

#### What happened instead:

<!--
PLEASE NOTE
- These comments won't show up when you submit the issue.
- Everything is optional, but try to add as many details as possible.
- If requesting a new feature, explain why you'd like to see it added.
- This issue tracker is not for support.
-->
